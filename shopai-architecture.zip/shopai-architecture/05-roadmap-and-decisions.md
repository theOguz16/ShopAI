# Uygulama sırası ve karar kaydı

## İş sırası

| İş | Kapsam | Bağımlılık | Tamamlanma ölçütü |
|---|---|---|---|
| S01 | pnpm repo, TS, lint, task runner, lockfile | Yok | Temiz kurulum ve boş uygulama build'leri |
| S02 | contracts, DB migration, merchant üyeliği | S01 | A/B tenant erişim testi geçiyor |
| S03 | CSV import, worker, outbox, hata raporu | S02 | Aynı dosya tekrarında kopya yok; yarıda devam var |
| S04 | Yayın kontrolü, filtreli katalog arama | S03 | Taslak dışarı çıkmıyor; varyant filtreleri doğru |
| S05 | Minimal web keşfi ve panel | S04 | Gerçek katalog yüklenip taranıyor |
| S06 | Query parser ve Türkçe eval seti | S04 | Sert filtre ihlali yok; fallback çalışıyor |
| S07 | MCP araçları ve widget | S04 | Aynı sorgu web/MCP'de aynı iş kuralını izliyor |
| S08 | İmzalı redirect ve tıklama raporu | S05, S07 | Gerçek yönlendirme kaydediliyor; URL üretimi sayılmıyor |
| S09 | Pilotun canlı connector'ı | S03, mağaza yetkisi | Sync hatası, güncellik ve limit davranışı doğrulanıyor |
| S10 | Conversion adaptörü, yalnız destek varsa | S08, kanıt erişimi | Tekrarlanan sipariş/iade doğru hesaplanıyor |
| S11 | Staging/pilot yayını ve operasyon kontrolü | S06–S09 | E2E, restore ve platform testi tamam |

S10 satış kanıtı yoksa ertelenir; demo ve tıklama raporu buna bağımlı değildir. S07 erken teknik risk denemesi için sentetik veriyle S03 sürerken ayrıca yapılabilir. Bu iş sıralaması kişi veya süre taahhüdü değildir.

## İlk geliştirme dilimi

Hedef: bir merchant, üç varyantlı örnek ürün, CSV import, SQL filtreleme, ürün kartı ve doğru mağaza bağlantısı. Önce bu akış DB ve web üzerinde çalıştırılır; aynı `SearchProducts` use case'i MCP'ye bağlanır. Tam dashboard ve AI zenginleştirme bu dilime eklenmez.

## Mimari kararlar

| Karar | Gerekçe | Yeniden değerlendirme tetikleyicisi |
|---|---|---|
| pnpm monorepo | Tek dil, ortak sözleşmeler, atomik değişiklik | Ekip/teknoloji sınırları ayrışırsa |
| Modüler monolit + worker | İş kuralları ortak, uzun işler request dışında | Ölçülen bağımsız ölçek ihtiyacı |
| REST ve MCP aynı API | Auth ve arama kurallarının tekrarını önler | MCP trafik/erişim politikası ayrışırsa |
| CSV ilk adaptör | Gerçek veriyle en kısa doğrulama | Pilot mağazanın canlı kaynak ihtiyacı |
| Product/Variant/Offer ayrımı | Beden-fiyat-stok tutarlılığı | Mağazalar arası ürün eşleme gerekirse |
| PostgreSQL ilk arama | İşletim yükü düşük ve filtreler kesin | Eval doğruluğu/gecikme hedefleri karşılanmazsa |
| Anonim keşif | Kullanıcı hesabı ilk akışı zorlaştırmaz | Wishlist/profil talebi doğrulanırsa |
| Dış checkout | Pilot ürün keşfine odaklanır | İş modeli ve platform erişimi doğrulanırsa |
| Gemini adaptörü sonra | İlk kanalı öğrenmeden yayılmayı önler | Gerçek ikinci kanal müşterisi varsa |

## Kodlamadan önce netleşecek dış bağımlılıklar

- İlk merchant, ürün kullanım/yayın izni ve veri dosyası.
- Canlı kaynak seçimi: Trendyol, Shopify veya başka bir sistem; hepsi birlikte yapılmayacak.
- Auth sağlayıcısı, staging alan adı ve hosting hesabı.
- LLM hesabı, model ve aylık bütçe; model ID config olur, koda gömülmez.
- ChatGPT bağlantı testi ve dağıtım/inceleme gereklilikleri.
- Checkout hedefi ve satış attribution verisinin gerçekten alınabilirliği.

Bu maddeler mimariyi yazmayı engellemez. Gerçek bağlantı ve yayın aşamasında ilgili erişimler gerekir.

## Pilotun devam kararı

Teknik çıktı: güvenilir katalog, doğru varyant, çalışan web/MCP akışı, gözlemlenebilir senkron.

Ticari çıktı: kullanıcı uygun ürünü buluyor; mağaza sonucu görüyor ve ücretli devam etmeyi kabul ediyor. Bağlanan SKU sayısı veya sadece tool çağrısı ticari doğrulama sayılmaz. Marka kendi trafiğini getiriyorsa ölçülen ilk değer dönüşüm desteğidir; yeni müşteri kazanımı ayrıca ölçülür.
